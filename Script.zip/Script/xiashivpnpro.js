/***********************************

> 應用名稱：夏时VPN
> 軟件版本：2.4.8
> 下載地址：https://apps.apple.com/us/app/id1544742935
> 腳本作者：Cuttlefish
> 微信賬號：墨魚手記
> 解鎖說明：解鎖高級會員權限
> 更新時間：2022-05-03
> 通知頻道：https://t.me/ddgksf2021
> 問題反饋：https://t.me/ddgksf2013_bot
> 特別說明：⛔⛔⛔
           本腳本僅供學習交流使用，禁止轉載售賣
           ⛔⛔⛔

[rewrite_local]

# ～ 夏时VPN解鎖會員權限（2022-05-03）@ddgksf2013
^https?:\/\/hotspot-unlimited\.com\/addressx2\/ url response-body vip":"1 response-body vip":"0

[mitm] 

hostname=hotspot-unlimited.com

***********************************/





